
import unittest
from unittest.mock import MagicMock
from program import Database, OldSystem, NewSystemAdapter, Subject, Observer

# TDD: тесты для шаблона Singleton
class TestSingleton(unittest.TestCase):
    def test_singleton_instance(self):
        db1 = Database()
        db2 = Database()
        self.assertIs(db1, db2)
        db1.insert("test_key", "test_value")
        self.assertEqual(db2.data["test_key"], "test_value")

# TDD: тесты для адаптера
class TestAdapter(unittest.TestCase):
    def test_adapter(self):
        old_system = OldSystem()
        adapter = NewSystemAdapter(old_system)
        self.assertEqual(adapter.get_data(), "Data from old system")

# BDD: тесты для наблюдателя
class TestObserver(unittest.TestCase):
    def test_observer(self):
        subject = Subject()
        observer = Observer()

        # Mock-объект для наблюдателя
        observer.update = MagicMock()
        subject.add_observer(observer)
        subject.notify("Test message")

        # Проверяем вызов метода update с правильным аргументом
        observer.update.assert_called_with("Test message")

if __name__ == "__main__":
    unittest.main()
