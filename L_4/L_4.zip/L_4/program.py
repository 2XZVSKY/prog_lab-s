
# Singleton Pattern
class SingletonMeta(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            instance = super().__call__(*args, **kwargs)
            cls._instances[cls] = instance
        return cls._instances[cls]

class Database(metaclass=SingletonMeta):
    def __init__(self):
        self.data = {}

    def insert(self, key, value):
        self.data[key] = value

# Adapter Pattern
class OldSystem:
    def request(self):
        return "Data from old system"

class NewSystemAdapter:
    def __init__(self, old_system):
        self.old_system = old_system

    def get_data(self):
        return self.old_system.request()

# Observer Pattern
class Subject:
    def __init__(self):
        self._observers = []

    def add_observer(self, observer):
        self._observers.append(observer)

    def notify(self, message):
        for observer in self._observers:
            observer.update(message)

class Observer:
    def update(self, message):
        print(f"Received message: {message}")

# Пример использования
if __name__ == "__main__":
    # Singleton Example
    db1 = Database()
    db2 = Database()
    db1.insert("key1", "value1")
    assert db1 is db2  # Проверка Singleton
    print(db1.data)  # Вывод: {'key1': 'value1'}

    # Adapter Example
    old_system = OldSystem()
    adapter = NewSystemAdapter(old_system)
    print(adapter.get_data())  # Вывод: "Data from old system"

    # Observer Example
    subject = Subject()
    observer1 = Observer()
    subject.add_observer(observer1)
    subject.notify("Hello, Observers!")
